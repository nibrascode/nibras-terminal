print("Salam, Nibras Terminal!")
